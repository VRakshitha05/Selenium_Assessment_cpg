Action()
{
    web_set_sockets_option("SSL_VERSION", "AUTO");

    web_add_auto_header("Accept-Language",
        "en-US,en;q=0.9");


    /*=====================================================
      1. NAVIGATE
    =====================================================*/

    lr_start_transaction("1_Navigate");

    web_url("demowebshop.tricentis.com",
        "URL=https://demowebshop.tricentis.com/",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=",
        "Mode=HTML",
        LAST);

    lr_end_transaction("1_Navigate", LR_AUTO);

    lr_think_time(5);


    /*=====================================================
      2. REGISTER
    =====================================================*/

    lr_start_transaction("2_Register");

    /*
     * Correlation:
     * Capture RequestVerificationToken from Register page
     */

    web_reg_save_param_regexp(
        "ParamName=C_RequestVerificationToken",
        "RegExp=name=\"__RequestVerificationToken\"[^>]+value=\"([^\"]+)\"",
        "Ordinal=1",
        SEARCH_FILTERS,
        "Scope=Body",
        "IgnoreRedirections=No",
        LAST);

    web_url("Register",
        "URL=https://demowebshop.tricentis.com/register",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/",
        "Mode=HTML",
        LAST);

    web_submit_data("register",
        "Action=https://demowebshop.tricentis.com/register",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/register",
        "Mode=HTML",
        "ITEMDATA",

        "Name=__RequestVerificationToken",
        "Value={C_RequestVerificationToken}",
        ENDITEM,

        "Name=Gender",
        "Value=F",
        ENDITEM,

        "Name=FirstName",
        "Value={p_FirstName}",
        ENDITEM,

        "Name=LastName",
        "Value={p_LastName}",
        ENDITEM,

        "Name=Email",
        "Value={p_Email}",
        ENDITEM,

        "Name=Password",
        "Value={p_Password}",
        ENDITEM,

        "Name=ConfirmPassword",
        "Value={p_Password}",
        ENDITEM,

        "Name=register-button",
        "Value=Register",
        ENDITEM,

        LAST);

    lr_end_transaction("2_Register", LR_AUTO);

    lr_think_time(5);


    /*=====================================================
      3. CATEGORY
    =====================================================*/

    lr_start_transaction("3_Categories");

    web_url("Category",
        "URL=https://demowebshop.tricentis.com/jewelry",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/",
        "Mode=HTML",
        LAST);

    lr_end_transaction("3_Categories", LR_AUTO);

    lr_think_time(5);


    /*=====================================================
      4. PRODUCT
    =====================================================*/

    lr_start_transaction("4_Product");

    web_url("Product",
        "URL=https://demowebshop.tricentis.com/black-white-diamond-heart",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/jewelry",
        "Mode=HTML",
        LAST);

    lr_end_transaction("4_Product", LR_AUTO);

    lr_think_time(5);


    /*=====================================================
      5. ADD TO CART
    =====================================================*/

    lr_start_transaction("5_AddToCart");

    web_submit_data("AddToCart",
        "Action=https://demowebshop.tricentis.com/addproducttocart/details/14/1",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/black-white-diamond-heart",
        "Mode=HTML",
        "ITEMDATA",

        "Name=addtocart_14.EnteredQuantity",
        "Value=1",
        ENDITEM,

        LAST);

    lr_end_transaction("5_AddToCart", LR_AUTO);

    lr_think_time(5);


    /*=====================================================
      6. CART
    =====================================================*/

    lr_start_transaction("6_Cart");

    web_url("Cart",
        "URL=https://demowebshop.tricentis.com/cart",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/black-white-diamond-heart",
        "Mode=HTML",
        LAST);

    lr_end_transaction("6_Cart", LR_AUTO);

    lr_think_time(5);


    /*=====================================================
      7. CHECKOUT
    =====================================================*/

    lr_start_transaction("7_Checkout");

    web_submit_data("Checkout",
        "Action=https://demowebshop.tricentis.com/cart",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/cart",
        "Mode=HTML",
        "ITEMDATA",

        "Name=termsofservice",
        "Value=on",
        ENDITEM,

        "Name=checkout",
        "Value=checkout",
        ENDITEM,

        LAST);

    lr_think_time(5);


    /*=====================================================
      8. BILLING
    =====================================================*/

    web_submit_data("OpcSaveBilling",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTML",
        "ITEMDATA",

        "Name=BillingNewAddress.Id",
        "Value=0",
        ENDITEM,

        "Name=BillingNewAddress.FirstName",
        "Value={p_FirstName}",
        ENDITEM,

        "Name=BillingNewAddress.LastName",
        "Value={p_LastName}",
        ENDITEM,

        "Name=BillingNewAddress.Email",
        "Value={p_Email}",
        ENDITEM,

        "Name=BillingNewAddress.Company",
        "Value=",
        ENDITEM,

        "Name=BillingNewAddress.CountryId",
        "Value=86",
        ENDITEM,

        "Name=BillingNewAddress.StateProvinceId",
        "Value=0",
        ENDITEM,

        "Name=BillingNewAddress.City",
        "Value={p_City}",
        ENDITEM,

        "Name=BillingNewAddress.Address1",
        "Value={p_Address1}",
        ENDITEM,

        "Name=BillingNewAddress.Address2",
        "Value={p_Address2}",
        ENDITEM,

        "Name=BillingNewAddress.ZipPostalCode",
        "Value={p_Zip}",
        ENDITEM,

        "Name=BillingNewAddress.PhoneNumber",
        "Value={p_Phone}",
        ENDITEM,

        "Name=BillingNewAddress.FaxNumber",
        "Value=",
        ENDITEM,

        LAST);

    lr_think_time(5);


    /*=====================================================
      9. SHIPPING
    =====================================================*/

    web_submit_data("OpcSaveShipping",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTML",
        "ITEMDATA",

        "Name=shipping_address_id",
        "Value=5160535",
        ENDITEM,

        "Name=ShippingNewAddress.Id",
        "Value=0",
        ENDITEM,

        "Name=ShippingNewAddress.FirstName",
        "Value={p_FirstName}",
        ENDITEM,

        "Name=ShippingNewAddress.LastName",
        "Value={p_LastName}",
        ENDITEM,

        "Name=ShippingNewAddress.Email",
        "Value={p_Email}",
        ENDITEM,

        "Name=ShippingNewAddress.Company",
        "Value=",
        ENDITEM,

        "Name=ShippingNewAddress.CountryId",
        "Value=0",
        ENDITEM,

        "Name=ShippingNewAddress.StateProvinceId",
        "Value=0",
        ENDITEM,

        "Name=ShippingNewAddress.City",
        "Value=",
        ENDITEM,

        "Name=ShippingNewAddress.Address1",
        "Value=",
        ENDITEM,

        "Name=ShippingNewAddress.Address2",
        "Value=",
        ENDITEM,

        "Name=ShippingNewAddress.ZipPostalCode",
        "Value=",
        ENDITEM,

        "Name=ShippingNewAddress.PhoneNumber",
        "Value=",
        ENDITEM,

        "Name=ShippingNewAddress.FaxNumber",
        "Value=",
        ENDITEM,

        "Name=PickUpInStore",
        "Value=false",
        ENDITEM,

        LAST);

    lr_think_time(5);


    /*=====================================================
      10. SHIPPING METHOD
    =====================================================*/

    web_submit_data("OpcSaveShippingMethod",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTML",
        "ITEMDATA",

        "Name=shippingoption",
        "Value=Next Day Air___Shipping.FixedRate",
        ENDITEM,

        LAST);

    lr_think_time(3);


    /*=====================================================
      11. PAYMENT METHOD
    =====================================================*/

    web_submit_data("OpcSavePaymentMethod",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/",
        "Method=POST",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTML",
        "ITEMDATA",

        "Name=paymentmethod",
        "Value=Payments.PurchaseOrder",
        ENDITEM,

        LAST);

    lr_think_time(3);


    /*=====================================================
      12. PAYMENT INFORMATION
    =====================================================*/

    web_submit_data("OpcSavePaymentInfo",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/",
        "Method=POST",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTML",
        "ITEMDATA",

        "Name=PurchaseOrderNumber",
        "Value=",
        ENDITEM,

        LAST);

    /*
     * IMPORTANT:
     * Checkout transaction is ended ONLY HERE.
     */

    lr_end_transaction("7_Checkout", LR_AUTO);

    lr_think_time(5);


    /*=====================================================
      13. CONFIRM ORDER
    =====================================================*/

    lr_start_transaction("8_ConfirmOrder");

    web_custom_request("OpcConfirmOrder",
        "URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/",
        "Method=POST",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTML",
        LAST);


    web_url("OrderCompleted",
        "URL=https://demowebshop.tricentis.com/checkout/completed/",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTML",
        LAST);


    lr_end_transaction("8_ConfirmOrder", LR_AUTO);


    return 0;
}