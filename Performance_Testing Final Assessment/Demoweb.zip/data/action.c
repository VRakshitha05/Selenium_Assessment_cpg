Action()
{

	lr_start_transaction("1_Navigate");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("Nop.customer=174ab34e-4623-4d47-b255-e7c1968b8445; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("ARRAffinity=f4edb6097d47b618727013498965259efd35f8883f487e535625e82c6dc8570c; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("ARRAffinitySameSite=f4edb6097d47b618727013498965259efd35f8883f487e535625e82c6dc8570c; DOMAIN=demowebshop.tricentis.com");

	web_concurrent_start(NULL);

	web_url("styles.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("nivo-slider.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/nivo-slider.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("default.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.css", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("jquery-1.10.2.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-1.10.2.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("public.ajaxcart.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.ajaxcart.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-ui-1.10.3.custom.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("jquery.validate.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("public.common.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.common.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("jquery-migrate-1.2.1.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-migrate-1.2.1.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("jquery.validate.unobtrusive.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.unobtrusive.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("jquery.nivo.slider.js", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Scripts/jquery.nivo.slider.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("0000215.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000215.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("logo.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/logo.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("0000015_25-virtual-gift-card_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000015_25-virtual-gift-card_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("0000224_141-inch-laptop_125.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_125.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("0000172_build-your-own-cheap-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("0000201_build-your-own-expensive-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000201_build-your-own-expensive-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("0000240.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000240.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t26.inf", 
		LAST);

	web_url("0000031_build-your-own-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000031_build-your-own-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t27.inf", 
		LAST);

	web_url("favicon.ico", 
		"URL=https://demowebshop.tricentis.com/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t30.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(4);

	web_url("ga.js", 
		"URL=https://ssl.google-analytics.com/ga.js", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t19.inf", 
		LAST);

	web_concurrent_start(NULL);

	web_url("star-x-inactive.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-inactive.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("star-x-active.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-active.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("top-menu-divider.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-divider.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t23.inf", 
		LAST);

	web_url("loading.gif", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("__utm.gif", 
		"URL=https://ssl.google-analytics.com/r/__utm.gif?utmwv=5.7.2&utms=1&utmn=1934960951&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop&utmhid=352469060&utmr=-&utmp=%2F&utmht=1790875717369&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=1702889044&utmredir=1&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t25.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_cookie("__utma=78382081.1912965495.1790875717.1790875717.1790875717.1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmc=78382081; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmz=78382081.1790875717.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmt=1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.1.10.1790875717; DOMAIN=demowebshop.tricentis.com");

	web_concurrent_start(NULL);

	web_url("ui-bg_flat_75_ffffff_40x100.png", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Snapshot=t28.inf", 
		LAST);

	web_url("bullets.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t29.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("arrows.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t31.inf", 
		LAST);

	web_url("top-menu-triangle.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-triangle.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t32.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("1_Navigate",LR_AUTO);

	lr_think_time(25);

	lr_start_transaction("2_Register");

	web_url("Register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("__utm.gif_2", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=2&utmn=1172986346&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Register&utmhid=1281119952&utmr=0&utmp=%2Fregister&utmht=1790875742989&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t34.inf", 
		LAST);

	web_custom_request("upload", 
		"URL=https://beacons.gcp.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t35.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":72777,\"request_elapsed_ms\":141,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://www.google.com/\",\"was_proxied\":false}],\"reporter\":\"chrome\"}", 
		LAST);

	web_add_cookie("__RequestVerificationToken=CT8-gsZPSNJKVs6zuGCx_JDxUtuIXYP9ORc8YTSWDFhnn83RmDW-hunx5BEk2Ew6JGfhdW4Xuz5-BEEyLs1ZnMaAUvUSI3aQ5k8gMCwgcEM1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.2.10.1790875717; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(6);

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t36.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=cjDIhjC4E3ilYgcs5Oc7fspHqbmXYIhTkdvIyehWbMMwjwPXApQ5VkqRZgjrdRbQWTedVMk1ko2O_USuz_VLNsrF5pjjpeYM-D4vhl9nA2k1", ENDITEM, 
		"Name=Gender", "Value=F", ENDITEM, 
		"Name=FirstName", "Value=Rakshu", ENDITEM, 
		"Name=LastName", "Value=Rakshi", ENDITEM, 
		"Name=Email", "Value=rakshi123@gmail.com", ENDITEM, 
		"Name=Password", "Value=sonu123", ENDITEM, 
		"Name=ConfirmPassword", "Value=sonu123", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_url("__utm.gif_3", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=3&utmn=837131302&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Register&utmhid=312656124&utmr=0&utmp=%2Fregister&utmht=1790875780806&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t37.inf", 
		LAST);

	web_add_cookie("__utmb=78382081.3.10.1790875717; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("NOPCOMMERCE.AUTH=CB208741DB0C9C70F473C43E82AB7E45AA8398D75C2DAE97BBD05166C98432BE8354B84BB804F9B7C222983E1634CEB09A87E7B1F4BF4F362481ED13D382438E0C50426DCAAC1973EE89B43EEE52AC91BBF797E2E77915906CA165D77512CE82D7C48CA7EE4ACA237FE166CFEA595191E7A9575096BB5CFA8B56BE86B1C03E91F91468BFA8192575F44B2D5C25E5C81A6E57E51732F35ED270C4B8C799FECD65E281E12012F294C4DC74E5CAF4D51348; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("register_2", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t38.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=SvePF77vVUTK2e9aiiFfwm39Z0_ojeQMX6RRkaA6tS6CKpYbYf_F37OkAKAZuRQslahWlkd7PS7ikIvuy7KWV31_bbj6rAb7j9XCGjclpN81", ENDITEM, 
		"Name=Gender", "Value=F", ENDITEM, 
		"Name=FirstName", "Value=Rakshu", ENDITEM, 
		"Name=LastName", "Value=Rakshi", ENDITEM, 
		"Name=Email", "Value=rakshiiii123@gmail.com", ENDITEM, 
		"Name=Password", "Value=sonu123", ENDITEM, 
		"Name=ConfirmPassword", "Value=sonu123", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_url("__utm.gif_4", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=4&utmn=210874311&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Register&utmhid=80975242&utmr=0&utmp=%2Fregisterresult%2F1&utmht=1790875794639&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t39.inf", 
		LAST);

	web_add_cookie("__utmb=78382081.4.10.1790875717; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("2_Register",LR_AUTO);

	lr_think_time(22);

	lr_start_transaction("3_Categories");

	web_url("Jewelry", 
		"URL=https://demowebshop.tricentis.com/jewelry", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/registerresult/1", 
		"Snapshot=t40.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("0000171_create-your-own-jewelry_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000171_create-your-own-jewelry_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/jewelry", 
		"Snapshot=t41.inf", 
		LAST);

	web_url("0000043_diamond-pave-earrings_125.jpg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000043_diamond-pave-earrings_125.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/jewelry", 
		"Snapshot=t42.inf", 
		LAST);

	web_url("0000071_vintage-style-three-stone-diamond-engagement-ring_125.jpg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000071_vintage-style-three-stone-diamond-engagement-ring_125.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/jewelry", 
		"Snapshot=t43.inf", 
		LAST);

	web_url("0000029_black-white-diamond-heart_125.jpg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000029_black-white-diamond-heart_125.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/jewelry", 
		"Snapshot=t44.inf", 
		LAST);

	web_url("0000044_diamond-tennis-bracelet_125.jpg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000044_diamond-tennis-bracelet_125.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/jewelry", 
		"Snapshot=t46.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_url("ico-arrow-r.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ico-arrow-r.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t45.inf", 
		LAST);

	web_url("__utm.gif_5", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=5&utmn=1594005420&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Jewelry&utmhid=159006064&utmr=0&utmp=%2Fjewelry&utmht=1790875819235&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t47.inf", 
		LAST);

	web_add_cookie("__utmb=78382081.5.10.1790875717; DOMAIN=demowebshop.tricentis.com");

	web_url("Black & White Diamond Heart", 
		"URL=https://demowebshop.tricentis.com/black-white-diamond-heart", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/jewelry", 
		"Snapshot=t48.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("NopCommerce.RecentlyViewedProducts=RecentlyViewedProductIds=14; DOMAIN=demowebshop.tricentis.com");

	web_concurrent_start(NULL);

	web_url("jquery.magnific-popup.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.magnific-popup.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/black-white-diamond-heart", 
		"Snapshot=t49.inf", 
		LAST);

	web_url("magnific-popup.css", 
		"URL=https://demowebshop.tricentis.com/Content/magnific-popup/magnific-popup.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/black-white-diamond-heart", 
		"Snapshot=t50.inf", 
		LAST);

	web_url("0000029_black-white-diamond-heart_300.jpg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000029_black-white-diamond-heart_300.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/black-white-diamond-heart", 
		"Snapshot=t51.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("free-shipping.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/free-shipping.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t52.inf", 
		LAST);

	web_url("__utm.gif_6", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=6&utmn=1416479016&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Black%20%26%20White%20Diamond%20Heart&utmhid=848455472&utmr=0&utmp=%2Fblack-white-diamond-heart&utmht=1790875831432&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D"
		"(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu=qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t53.inf", 
		LAST);

	web_url("ajax_loader_large.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_large.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t54.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("3_Categories",LR_AUTO);

	lr_think_time(33);

	lr_start_transaction("4_Addtocart");

	web_submit_data("1", 
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/14/1", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/black-white-diamond-heart", 
		"Snapshot=t55.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=addtocart_14.EnteredQuantity", "Value=1", ENDITEM, 
		LAST);

	web_custom_request("upload_2", 
		"URL=https://beacons.gcp.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t56.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"http_response_code\":200,\"network_changed\":false,\"protocol\":\"HTTP\",\"request_age_ms\":87670,\"request_elapsed_ms\":1997,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/domainreliability/upload\",\"was_proxied\":true}],\"reporter\":\"chrome\"}", 
		LAST);

	web_concurrent_start(NULL);

	web_url("0000029_black-white-diamond-heart_47.jpg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000029_black-white-diamond-heart_47.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/black-white-diamond-heart", 
		"Snapshot=t57.inf", 
		LAST);

	web_url("ico-close-notification-bar.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t58.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(5);

	web_url("cart", 
		"URL=https://demowebshop.tricentis.com/cart", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/black-white-diamond-heart", 
		"Snapshot=t59.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("__utm.gif_7", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=7&utmn=1543336604&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Shopping%20Cart&utmhid=911958314&utmr=0&utmp=%2Fcart&utmht=1790875866129&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t60.inf", 
		LAST);

	web_url("0000029_black-white-diamond-heart_80.jpg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000029_black-white-diamond-heart_80.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t61.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_cookie("__utmb=78382081.7.10.1790875717; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(13);

	web_url("ajax_loader_small.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_small.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t62.inf", 
		LAST);

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=86&addEmptyStateIfRequired=true&_=1790875866001", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t63.inf", 
		"Mode=HTTP", 
		LAST);

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t64.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=removefromcart", "Value=7123336", ENDITEM, 
		"Name=itemquantity7123336", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=86", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	web_url("public.onepagecheckout.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.onepagecheckout.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t65.inf", 
		LAST);

	web_url("__utm.gif_8", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=8&utmn=549801953&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Checkout&utmhid=931918290&utmr=0&utmp=%2Fonepagecheckout&utmht=1790875887876&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu="
		"qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t66.inf", 
		LAST);

	lr_end_transaction("4_Addtocart",LR_AUTO);

	lr_start_transaction("5_Checkout");

	web_add_cookie("__utmb=78382081.8.10.1790875717; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(17);

	web_url("getstatesbycountryid_2", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=86&addEmptyStateIfRequired=true&_=1790875886893", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t67.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("top-menu-list-image.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-list-image.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t68.inf", 
		LAST);

	web_url("top-menu-background.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-background.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t69.inf", 
		LAST);

	web_url("top-menu-list-image-hover.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-list-image-hover.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t70.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(33);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t71.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value=Rakshu", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value=Rakshi", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value=rakshiiii123@gmail.com", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=86", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value=Ballari", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value=Royal", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value=Sp", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value=583101", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value=123456789", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	web_url("arrow-up.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/arrow-up.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t72.inf", 
		LAST);

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t73.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5160535", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value=Rakshu", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=Rakshi", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value=rakshiiii123@gmail.com", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_submit_data("OpcSaveShipping_2", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t74.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5160535", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value=Rakshu", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=Rakshi", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value=rakshiiii123@gmail.com", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	web_custom_request("upload_3", 
		"URL=https://beacons.gcp.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t75.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"http_response_code\":200,\"network_changed\":false,\"protocol\":\"HTTPS\",\"quic_broken\":true,\"request_age_ms\":60165,\"request_elapsed_ms\":104,\"sample_rate\":0.05,\"server_ip\":\"10.208.95.44:8888\",\"status\":\"ok\",\"url\":\"https://ssl.google-analytics.com/__utm.gif\",\"was_proxied\":true}],\"reporter\":\"chrome\"}", 
		LAST);

	lr_think_time(32);

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t76.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Next Day Air___Shipping.FixedRate", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("logo.jpg", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.Manual/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t77.inf", 
		LAST);

	web_url("logo.jpg_2", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.PurchaseOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t78.inf", 
		LAST);

	web_url("logo.jpg_3", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CashOnDelivery/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t79.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(4);

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t80.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.PurchaseOrder", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_submit_data("OpcSavePaymentInfo", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t81.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=PurchaseOrderNumber", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("5_Checkout",LR_AUTO);

	lr_start_transaction("6_Confirm");

	web_add_cookie("ASP.NET_SessionId=quacvrmz22djciamuijgbzvg; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(18);

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t82.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_custom_request("upload_4", 
		"URL=https://beacons.gcp.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t83.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"http_response_code\":200,\"network_changed\":false,\"protocol\":\"HTTP\",\"request_age_ms\":61295,\"request_elapsed_ms\":198,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/domainreliability/upload\",\"was_proxied\":true}],\"reporter\":\"chrome\"}", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t84.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("__utm.gif_9", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=11&utmn=64670896&utmhn=demowebshop.tricentis.com&utmt=item&utmtid=2394118&utmipc=&utmipn=Black%20%26%20White%20Diamond%20Heart&utmiva=Jewelry&utmipr=130.00&utmiqt=1&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Checkout&utmhid=692043521&utmr=0&utmp=%2Fcheckout%2Fcompleted%2F&utmht=1790876010541&utmac=UA-6574346-11&utmcc="
		"__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu=qAALAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t85.inf", 
		LAST);

	web_url("__utm.gif_10", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=9&utmn=431017274&utmhn=demowebshop.tricentis.com&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Checkout&utmhid=692043521&utmr=0&utmp=%2Fcheckout%2Fcompleted%2F&utmht=1790876010538&utmac=UA-6574346-11&utmcc=__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid="
		"&utmu=qAAAAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t86.inf", 
		LAST);

	web_url("__utm.gif_11", 
		"URL=https://ssl.google-analytics.com/__utm.gif?utmwv=5.7.2&utms=10&utmn=1892733204&utmhn=demowebshop.tricentis.com&utmt=tran&utmtid=2394118&utmtst=demowebshop.tricentis.com&utmtto=130.00&utmttx=0.00&utmtsp=0.00&utmtci=Ballari&utmtrg=&utmtco=Afghanistan&utmcs=UTF-8&utmsr=1536x864&utmvp=1521x730&utmsc=24-bit&utmul=en-us&utmje=0&utmfl=-&utmdt=Demo%20Web%20Shop.%20Checkout&utmhid=692043521&utmr=0&utmp=%2Fcheckout%2Fcompleted%2F&utmht=1790876010541&utmac=UA-6574346-11&utmcc="
		"__utma%3D78382081.1912965495.1790875717.1790875717.1790875717.1%3B%2B__utmz%3D78382081.1790875717.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu=qAALAAAAAAAAAAAAAAAAAAAE~", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t87.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("6_Confirm",LR_AUTO);

	return 0;
}