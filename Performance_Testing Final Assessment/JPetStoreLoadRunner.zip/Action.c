Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-{p_Country},en;q=0.9");

/*Correlation comment - Do not change!  Original value='CATS' Name ='C_Category' Type ='Manual'*/
	web_reg_save_param_regexp(
    "ParamName=C_Category",
    "RegExp=categories/(.*?)\">",
    "Ordinal=1",
    SEARCH_FILTERS,
    "Scope=Body",
    "IgnoreRedirections=No",
    "RequestUrl=*/jpetstore.aspectran.com/*",
    LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(9);

	lr_start_transaction("1_Navigate");

	lr_end_transaction("1_Navigate",LR_AUTO);

	lr_start_transaction("2_SignIn");

	web_url("Sign In", 
		"URL=https://jpetstore.aspectran.com/account/signonForm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=referer", "Value=", ENDITEM, 
		"Name=username", "Value={P_username}", ENDITEM, 
		"Name=password", "Value={P_password}", ENDITEM, 
		LAST);

	lr_end_transaction("2_SignIn",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("3_Addproduct");

/*Correlation comment - Do not change!  Original value='FL-DSH-01' Name ='C_Product' Type ='Manual'*/
	web_reg_save_param_regexp(
    "ParamName=C_Product",
    "RegExp=products/(.*?)\">",
    "Ordinal=1",
    SEARCH_FILTERS,
    "Scope=Body",
    "IgnoreRedirections=No",
    LAST);

	web_url("Cats",
		"URL=https://jpetstore.aspectran.com/categories/{C_Category}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t16.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("3_Addproduct",LR_AUTO);

	lr_think_time(19);

	lr_start_transaction("4_ProductItem");

/*Correlation comment - Do not change!  Original value='EST-34' Name ='C_item' Type ='Manual'*/
	web_reg_save_param_regexp(
    "ParamName=C_item",
    "RegExp=items/(.*?)\">",
    "Ordinal=1",
    SEARCH_FILTERS,
    "Scope=Body",
    "IgnoreRedirections=No",
    LAST);

	web_url("FL-DSH-01",
		"URL=https://jpetstore.aspectran.com/products/{C_Product}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{C_Category}",
		"Snapshot=t17.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("4_ProductItem",LR_AUTO);

	lr_think_time(29);

	lr_start_transaction("5_addToCart");

	web_url("EST-34",
		"URL=https://jpetstore.aspectran.com/products/{C_Product}/items/{C_item}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}",
		"Snapshot=t18.inf",
		"Mode=HTML",
		LAST);

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={C_item}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}/items/{C_item}",
		"Snapshot=t19.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("5_addToCart",LR_AUTO);

	lr_think_time(26);

	lr_start_transaction("6_proceedtocheckout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("6_proceedtocheckout",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("7_confirmation");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value={p_Country}", ENDITEM, 
		LAST);

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("7_confirmation",LR_AUTO);

	return 0;
}